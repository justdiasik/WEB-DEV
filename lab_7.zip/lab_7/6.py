v = int(input())
t = int(input())
print((v * t) % 109)