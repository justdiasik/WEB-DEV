v=int(input())
t=int(input())
b=abs(v*t)
d=abs(109-b)

print(d)