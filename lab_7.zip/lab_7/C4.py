n = int(input())
a = 2
b = 1
while a <= n:
    a *= 2
    b += 1
print(b - 1, a // 2)
