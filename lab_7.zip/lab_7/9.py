sys=int(input())
stud=int(input())
if (sys!=1 and stud!=1 or sys==1 and stud==1):
    print("YES")
else:
    print("NO")
