a=int((input())
s1 = "The next number for the number"
s2 = "is" 
s3 = "The previous number for the number"
e=a+1)
f=(a-1)
print(s1)


