n=int(input())
k=int(input())
c=k%n
print(c)